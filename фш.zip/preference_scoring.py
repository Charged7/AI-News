from impact_ai import ImpactDecision


TOPIC_WEIGHTS = {
    "llm": 30,
    "ai": 20,
    "technology": 10,

    "ukraine": 15,
    "russia": 10,

    "earthquake": -20,
    "natural_disaster": -10,
    "israel_gaza": -25,
}


def preference_score(decision: ImpactDecision) -> int:
    score = decision.impact_score

    for topic in decision.topics:
        score += TOPIC_WEIGHTS.get(topic, 0)

    return score