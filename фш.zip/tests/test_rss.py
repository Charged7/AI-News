"""Тести для RSS-нормалізації, дат, зображень і дедуплікації."""

from __future__ import annotations

import unittest
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import patch

from config import RSSSource
from rss import NewsItem, deduplicate_news, extract_image, fetch_recent_news, is_recent


class RssTests(unittest.TestCase):
    """Перевіряє базові RSS-хелпери без живих зовнішніх запитів."""

    def test_is_recent_keeps_only_items_inside_lookback_window(self) -> None:
        now = datetime(2026, 5, 20, 9, 0, tzinfo=UTC)
        recent = NewsItem("A", "Desc", "https://a.test", None, "Source", now - timedelta(hours=1))
        old = NewsItem("B", "Desc", "https://b.test", None, "Source", now - timedelta(hours=25))
        undated = NewsItem("C", "Desc", "https://c.test", None, "Source", None)

        self.assertTrue(is_recent(recent, 24, now))
        self.assertFalse(is_recent(old, 24, now))
        self.assertFalse(is_recent(undated, 24, now))

    def test_extract_image_prefers_media_content(self) -> None:
        entry = {
            "media_content": [{"url": "https://cdn.test/image.jpg", "type": "image/jpeg"}],
            "summary": '<p><img src="https://cdn.test/other.jpg"></p>',
        }

        self.assertEqual(extract_image(entry), "https://cdn.test/image.jpg")

    def test_extract_image_uses_enclosure_or_html(self) -> None:
        enclosure_entry = {"enclosures": [{"href": "https://cdn.test/photo.png", "type": "image/png"}]}
        html_entry = {"summary": '<p>Hello <img src="https://cdn.test/html.webp"></p>'}

        self.assertEqual(extract_image(enclosure_entry), "https://cdn.test/photo.png")
        self.assertEqual(extract_image(html_entry), "https://cdn.test/html.webp")

    def test_deduplicate_news_by_link_then_title(self) -> None:
        first = NewsItem("Same Title", "Desc", "https://a.test", None, "A")
        duplicate_link = NewsItem("Different", "Desc", "https://a.test", None, "B")
        duplicate_title = NewsItem("same title", "Desc", "https://b.test", None, "B")
        unique = NewsItem("Unique", "Desc", "https://c.test", None, "C")

        self.assertEqual(deduplicate_news([first, duplicate_link, duplicate_title, unique]), [first, unique])

    def test_fetch_recent_news_skips_broken_sources(self) -> None:
        now = datetime(2026, 5, 20, 9, 0, tzinfo=UTC)
        broken_feed = SimpleNamespace(entries=[], bozo=True, bozo_exception=RuntimeError("broken"))
        working_feed = SimpleNamespace(
            entries=[
                {
                    "title": "Major event",
                    "link": "https://example.test/major",
                    "summary": "Important text",
                    "published_parsed": now.utctimetuple(),
                }
            ],
            bozo=False,
        )

        with patch("rss.feedparser.parse", side_effect=[broken_feed, working_feed]):
            items = fetch_recent_news(
                [
                    RSSSource("Broken", "https://broken.test/rss"),
                    RSSSource("Working", "https://working.test/rss", category="world", priority="high"),
                ],
                lookback_hours=24,
                now=now,
            )

        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].source, "Working")
        self.assertEqual(items[0].source_category, "world")
        self.assertEqual(items[0].source_priority, "high")


if __name__ == "__main__":
    unittest.main()
